# MLMS Release Notes - Version 1.0.0 (Phase 7 Production Release)

## Release Highlights
- **Role-Based Access Control (RBAC)**: Enforces strict separation of duties between Admin, Lecturer, HoD, and Student roles.
- **SQLite3 Embedded Database**: Full persistent relational database layer with WAL journal mode and foreign key integrity.
- **Extensible Penalty Engine**: Implements Strategy Pattern for automated late mark calculations.
- **Grade Moderation & Audit Logging**: Complete historical tracking for grade edits and moderation reviews.

## Fixed Issues & Optimizations
- Resolved password verification logic to ensure salted djb2 hashing consistency across all platforms.
- Configured dynamic SQLite prepared statements to prevent SQL injection vulnerabilities across all repositories.
