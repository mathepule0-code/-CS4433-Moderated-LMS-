# CS4433 - Phase 7: Software Delivery, Deployment & User Operations Manual

## 1. System Overview & Deployment Architecture
The Moderated Learning Management System (MLMS) is delivered as a modular C++17 desktop/CLI application backed by an embedded SQLite3 relational database engine.

### System Deployment Diagram:
```text
+-----------------------------------------------------------------------+
|                            Client Node                                |
|                        (Student / Lecturer / HoD)                     |
|                                                                       |
|   +---------------------------------------------------------------+   |
|   |                        CLI Presentation                       |   |
|   |                (Standard Terminal / Console)                  |   |
|   +---------------------------------------------------------------+   |
+-----------------------------------|-----------------------------------+
                                    | 
                                    | Standard Input / Output (CLI)
                                    v
+-----------------------------------------------------------------------+
|                         Execution Host / Node                         |
|                                                                       |
|   +---------------------------------------------------------------+   |
|   |                      MLMS Application                         |   |
|   |                        Core (C++17)                           |   |
|   |                                                               |   |
|   |   - User Management & RBAC                                    |   |
|   |   - Strategy Pattern (Late Penalties)                         |   |
|   |   - GoogleTest QA Module                                      |   |
|   +---------------------------------------------------------------+   |
|                                   |                                   |
|                                   | SQL API / Transactions            |
|                                   v                                   |
|   +---------------------------------------------------------------+   |
|   |                       Embedded Database                       |   |
|   |                          SQLite3                              |   |
|   |            (Local Persistent File Storage: mlms.db)           |   |
|   +---------------------------------------------------------------+   |
+-----------------------------------------------------------------------+
```

### System Requirements:
* **Operating System**: Linux (Ubuntu 20.04 LTS or newer), macOS 12+, or Windows 10/11 (via WSL2 or MinGW64).
* **Compiler**: GCC 9+, Clang 10+, or MSVC 2019+ with C++17 support.
* **Build System**: CMake 3.14 or higher.
* **Database Engine**: SQLite 3.30+ runtime headers (`libsqlite3-dev`).

---

## 2. Installation & Build Guide

### Step 1: Clone Repository
```bash
git clone https://github.com/mathepule0-code/-CS4433-Moderated-LMS-.git
cd -CS4433-Moderated-LMS-
```

### Step 2: Build Executable
```bash
mkdir build && cd build
cmake ..
make -j4
```

### Step 3: Run System
```bash
./mlms
```

---

## 3. Role-Based User Manuals & Workflows

### 3.1 Administrator (System Admin)
* **User Provisioning**: Execute user registration commands to establish initial credentials for Lecturers, HoDs, and Students.
* **Department & Course Management**: Provision academic departments and assign course codes to database schemas.

### 3.2 Lecturer
* **Assignment Creation**: Publish course assignments, setting explicit submission deadlines and maximum achievable marks.
* **Marking & Grade Entry**: Grade student submissions, record raw scores, and input qualitative feedback.
* **Late Penalty Application**: System automatically invokes `StandardLatePenalty` strategy (10% per day late, max 100% after 3 days).

### 3.3 Head of Department (HoD)
* **Grade Moderation**: Inspect graded assignment lists within department scope.
* **Audit Trail Verification**: Review `AuditLogs` for any grade modifications, ensuring reason strings and timestamp logs are validated prior to final grade release.

### 3.4 Student
* **Assignment Submission**: Upload digital assignment artifacts prior to deadlines.
* **Grade & Feedback Inspection**: View final moderated marks, penalty deductions, and lecturer commentary.
