# Phase 3 Deliverable: Software Design Document (SDD)
**Project:** Moderated Learning Management System (MLMS)  
**Course:** CS4433 Software Engineering  

---

## 1. System Architecture (5 Marks)

### 1.1 Architectural Style
The system adopts a **Layered (N-Tier) Architecture** with strict separation of concerns across four primary layers:
1. **Presentation Layer (Console UI):** Handles role-based CLI menus and user interactions for Admin, Lecturer, HoD, and Student.
2. **Business Logic Layer:** Implements core LMS rules including authentication, deadline checks, late penalty calculation (Strategy Pattern), and moderation workflows.
3. **Data Access Layer (DAL):** Implements the Repository/DAO pattern using interface abstractions (`IRepository<T>`) to isolate SQL queries from business logic.
4. **Database Layer:** Local SQLite3 embedded engine providing durable, offline file persistence.

### 1.2 Rejected Alternative & Justification
* **Rejected Alternative:** Client-Server Architecture / Microservices.
* **Justification for Rejection:** The IT Officer explicitly stated that internet connectivity is highly unreliable and computers are aging [cite: 2]. A full microservices or web client-server setup introduces unnecessary network dependency, higher resource overhead, and deployment complexity [cite: 2]. The local N-Tier Layered C++ architecture ensures zero network latency, complete offline availability, and lightweight memory footprint [cite: 1, 2].

---

## 2. Detailed Class Design & Design Patterns (7 Marks)

### 2.1 Design Patterns Applied
1. **Strategy Pattern (`IPenaltyStrategy`):** Encapsulates late-penalty calculation logic (`StandardLatePenalty` vs. `ZeroPenalty`). Allows dynamically swapping rules (e.g., granting extensions) without altering submission engine logic.
2. **Factory Pattern (`UserFactory`):** Encapsulates user object creation based on role strings (`Student`, `Lecturer`, `HoD`, `Admin`) to ensure clean polymorphism.
3. **Repository / DAO Pattern (`ISubmissionRepository`):** Abstracts data access, enabling complete decoupling of C++ business entities from SQLite SQL operations.

### 2.2 Alignment with SOLID Principles
* **Single Responsibility Principle (SRP):** Classes have distinct responsibilities (e.g., `Submission` manages entity state, `SQLiteSubmissionRepository` handles SQL queries, `UserFactory` handles object creation).
* **Open/Closed Principle (OCP):** New late-penalty rules can be introduced by creating a new `IPenaltyStrategy` implementation without modifying existing engine code.
* **Liskov Substitution Principle (LSP):** All derived roles (`Student`, `Lecturer`, `HoD`) transparently substitute for abstract `User`.
* **Interface Segregation Principle (ISP):** DAO interfaces (`IUserRepository`, `ISubmissionRepository`) expose only domain-relevant operations.
* **Dependency Inversion Principle (DIP):** High-level business logic modules depend on repository abstractions (`IRepository`), not concrete SQLite implementations.

---

## 3. Behavioural Models (7 Marks)

1. **State Machine Diagram (`3_State_Machine_Diagram.png`):** Enforces submission lifecycle (`Submitted` -> `Late` -> `Marked` -> `Moderated` -> `Released`).
2. **Activity Diagram with Swimlanes (`4_Activity_Diagram.png`):** Maps end-to-end responsibilities across Student, System, Lecturer, and HoD swimlanes.
3. **Sequence Diagrams (`5_Sequence_Submit_Assignment.png`, `6_Sequence_Moderate_And_Release.png`):** Details step-by-step object messages, parameter passing, and database interactions.

---

## 4. Database Design & SQL Schema (5 Marks)

### 4.1 SQL Schema (3NF)

```sql
CREATE TABLE IF NOT EXISTS Departments (
    department_id INTEGER PRIMARY KEY AUTOINCREMENT,
    department_name TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS Users (
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('Admin', 'Lecturer', 'HoD', 'Student')),
    department_id INTEGER,
    FOREIGN KEY (department_id) REFERENCES Departments(department_id)
);

CREATE TABLE IF NOT EXISTS Courses (
    course_id INTEGER PRIMARY KEY AUTOINCREMENT,
    course_code TEXT NOT NULL UNIQUE,
    department_id INTEGER NOT NULL,
    FOREIGN KEY (department_id) REFERENCES Departments(department_id)
);

CREATE TABLE IF NOT EXISTS Assignments (
    assignment_id INTEGER PRIMARY KEY AUTOINCREMENT,
    course_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    due_date TEXT NOT NULL,
    max_mark REAL NOT NULL CHECK(max_mark > 0),
    FOREIGN KEY (course_id) REFERENCES Courses(course_id)
);

CREATE TABLE IF NOT EXISTS Submissions (
    submission_id INTEGER PRIMARY KEY AUTOINCREMENT,
    assignment_id INTEGER NOT NULL,
    student_id INTEGER NOT NULL,
    submitted_at TEXT NOT NULL,
    raw_mark REAL DEFAULT 0.0,
    final_mark REAL DEFAULT 0.0,
    feedback TEXT,
    status TEXT NOT NULL DEFAULT 'Submitted' CHECK(status IN ('Submitted', 'Late', 'Marked', 'Moderated', 'Released')),
    FOREIGN KEY (assignment_id) REFERENCES Assignments(assignment_id),
    FOREIGN KEY (student_id) REFERENCES Users(user_id)
);

CREATE TABLE IF NOT EXISTS AuditLogs (
    log_id INTEGER PRIMARY KEY AUTOINCREMENT,
    submission_id INTEGER NOT NULL,
    changed_by_user_id INTEGER NOT NULL,
    timestamp TEXT NOT NULL,
    old_mark REAL,
    new_mark REAL,
    reason TEXT NOT NULL,
    FOREIGN KEY (submission_id) REFERENCES Submissions(submission_id),
    FOREIGN KEY (changed_by_user_id) REFERENCES Users(user_id)
);
```

### 4.2 Class-to-Table Mapping Justification
* **Inheritance Mapping:** Class hierarchy (`User` -> `Student`/`Lecturer`/`HoD`) is mapped using a **Single Table Inheritance** pattern (`Users` table with a `role` discriminator column and optional `department_id` foreign key) to minimize database joins and optimize performance on legacy hardware [cite: 2].
