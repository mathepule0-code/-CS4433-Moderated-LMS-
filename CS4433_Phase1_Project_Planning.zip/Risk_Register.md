# Phase 1 Deliverable: Initial Risk Register
**Project:** Moderated Learning Management System (MLMS)  
**Lifecycle Stage:** Phase 1 Baseline (To be updated at Phase Gates 1, 2, and 3)

---

## Risk Exposure Scoring Matrix
* **Likelihood (L):** 1 (Unlikely) to 5 (Almost Certain)
* **Impact (I):** 1 (Negligible) to 5 (Critical)
* **Exposure (E):** $L 	imes I$ (Scale 1 to 25)

---

| Risk ID | Category | Risk Description | Likelihood (1-5) | Impact (1-5) | Exposure Score | Mitigation Strategy | Risk Owner |
| :--- | :--- | :--- | :---: | :---: | :---: | :--- | :--- |
| **RSK-01** | Technical | **Database Corruption / Data Loss:** Power failures or unexpected application shutdowns on offline school computers causing SQLite database corruption. | 2 | 5 | **10** | Implement SQLite Write-Ahead Logging (WAL) mode, atomic transactions (`BEGIN TRANSACTION`), and structured crash recovery. | Lead Developer |
| **RSK-02** | Technical | **Insecure Password Storage:** Plaintext or weakly hashed password exposure if local SQLite DB is extracted. | 2 | 5 | **10** | Utilize secure salted password hashing algorithms (e.g., Argon2 / bcrypt wrapper) with parameter verification. | Security Engineer |
| **RSK-03** | Schedule | **Scope Creep / Misaligned Stakeholders:** Unresolved conflicts between Principal, Lecturer, HoD, and Student requirements delaying Gate 1 sign-off. | 4 | 3 | **12** | Perform explicit stakeholder conflict resolution in Phase 2, formalize MoSCoW prioritization, and freeze baseline SRS at Gate 1. | Project Manager |
| **RSK-04** | People | **Knowledge Gap in C++ Core Patterns:** Delays during implementation due to complex C++ memory management (pointers, RAII) or design pattern implementation. | 3 | 3 | **9** | Standardize code on modern C++17 smart pointers (`std::unique_ptr`, `std::shared_ptr`), perform early prototyping in Phase 3. | Lead Developer |
| **RSK-05** | Quality | **Inadequate Test Coverage (<70% Target):** Late discovery of business logic bugs due to postponed unit test writing. | 3 | 4 | **12** | Enforce continuous test writing alongside feature implementation; set up automated CI pipeline builds with coverage reports. | QA Engineer |
| **RSK-06** | Project | **Gate Review Delays (Gate 2 Blocking):** Design changes required after Gate 2 review delaying start of Phase 4 implementation. | 3 | 4 | **12** | Perform pre-review self-audits on design documents against SRS requirements prior to Gate 2 submission. | Project Manager |

---

## Phase Gate Update Log
* **Phase 1 Baseline (Week 1):** Initial 6 risks identified and registered.
* **Gate 1 Review (Week 2):** *Pending*
* **Gate 2 Review (Week 3):** *Pending*
* **Gate 3 Review (Week 6):** *Pending*
