# Phase 1 Deliverable: Feasibility Study & Project Recommendation
**Project:** Moderated Learning Management System (MLMS)  
**Course:** CS4433 Software Engineering  
**Date:** October 2026  

---

## 1. Technical Feasibility
* **Evaluation:** High Feasibility.
* **Technology Stack:** C++17, SQLite3, CMake, Git, and GoogleTest/Catch2.
* **System Constraints:** The system is required to run offline on aging school hardware with up to 800 student records.
* **Technical Justification:**
  - **Performance & Footprint:** C++17 compiles to lean native code, ensuring low memory consumption and instant execution on legacy school hardware.
  - **Embedded Database:** SQLite operates locally as a self-contained file database, eliminating network overhead and ensuring full functionality without internet dependency.
  - **Security:** Standard C++ libraries combined with standard cryptographic functions allow robust salted password hashing without heavy server infrastructure.
* **Technical Risks:** Initial overhead in setting up C++ memory-safe practices and SQLite ORM/DAO abstractions; mitigated via strict RAII patterns and smart pointers.

---

## 2. Operational Feasibility
* **Evaluation:** High Feasibility (with targeted UI simplicity).
* **Stakeholder Environment:** Teachers have low IT familiarity, requiring an intuitive console or lightweight desktop UI.
* **Operational Justification:**
  - **Role-Based Workflows:** Distinct role perspectives (Student, Lecturer, HoD, Admin) reduce UI bloat by only displaying actions relevant to the logged-in actor.
  - **Moderation Workflow:** Enforces the Head of Department (HoD) review and approval step prior to releasing marks, aligning directly with organizational policy.
  - **Auditability:** Automated change logs track all mark modifications (who, when, why) to protect integrity without adding procedural complexity for users.

---

## 3. Economic Feasibility
* **Evaluation:** High Feasibility.
* **Cost Structure:**
  - **Software/Licensing Costs:** $0 (100% Open Source toolchain: C++17, SQLite, CMake, Git, Clang-Tidy/Cppcheck, GoogleTest).
  - **Infrastructure Costs:** $0 (Runs locally on existing school hardware; hosted Git free-tier for repository management).
  - **Labor Cost:** Academic individual assignment context (fixed student labor budget over 7 weeks).
* **Return on Investment (ROI):** High organizational value achieved by eliminating manual mark sheets and preventing unauthorized score modifications without capital expenditure.

---

## 4. Legal and Ethical Feasibility
* **Evaluation:** High Feasibility.
* **Compliance & Data Protection:**
  - Student records and marks constitute protected Personal Identifiable Information (PII) under applicable data protection acts.
  - Storing salted password hashes protects account safety against offline database exposure.
  - An immutable audit trail satisfies accountability obligations for grade integrity.
* **Fairness:** Late submission policies and penalty structures are programmatically enforced via standardized business rules, ensuring equitable treatment.

---

## 5. Schedule Feasibility
* **Evaluation:** Medium-High Feasibility (Tight 7-Week Timeline).
* **Schedule Justification:**
  - The Waterfall lifecycle with V-Model verification structures activities into weekly increments.
  - Mitigated by decoupling core C++ business logic from UI layers, prioritizing core functional "MUST" requirements first during implementation.

---

## 6. Justified Recommendation
**Recommendation:** **PROCEED WITH PROJECT (GO)**  
The proposed C++17/SQLite system architecture fully meets all operational offline requirements, satisfies strict privacy/security mandates, and incurs zero monetary cost. Schedule risks will be actively managed via the critical path identified in the Work Breakdown Structure.
