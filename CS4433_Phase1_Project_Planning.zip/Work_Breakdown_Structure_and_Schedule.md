# Phase 1 Deliverable: Work Breakdown Structure (WBS) & Schedule

## 1. Work Breakdown Structure (WBS)

1.0 Moderated LMS
├── 1.1 Project Management & Planning (Week 1)
│   ├── 1.1.1 Feasibility Study
│   ├── 1.1.2 Work Breakdown & Schedule (WBS / Gantt)
│   └── 1.1.3 Risk Register Formulation
├── 1.2 Requirements Engineering (Weeks 1-2)
│   ├── 1.2.1 Stakeholder & Conflict Analysis
│   ├── 1.2.2 Software Requirements Specification (ISO/IEC/IEEE 29148)
│   ├── 1.2.3 Use Case Modeling & Fully Dressed Specifications
│   └── 1.2.4 Phase Gate 1 Review
├── 1.3 System Design (Weeks 2-3)
│   ├── 1.3.1 Architectural Selection & Component Diagram
│   ├── 1.3.2 Detailed Class Diagram & Design Patterns Strategy
│   ├── 1.3.3 Behavioural Models (State, Activity, Sequence)
│   ├── 1.3.4 Database ERD, Data Dictionary & SQL Schema
│   └── 1.3.5 Phase Gate 2 Review
├── 1.4 Implementation (Weeks 4-5)
│   ├── 1.4.1 SQLite Integration & DAO / Repository Layer
│   ├── 1.4.2 User Auth, Password Hashing & Role Control
│   ├── 1.4.3 Assignment Submission & Penalty/Extension Engine
│   ├── 1.4.4 HoD Moderation Workflow & Audit Trail
│   └── 1.4.5 CLI / UI Development & Exception Handling
├── 1.5 Verification & Validation (Weeks 5-6)
│   ├── 1.5.1 Test Plan & V-Model Mapping
│   ├── 1.5.2 Unit Testing (GoogleTest/Catch2) & Coverage Setup
│   ├── 1.5.3 System / Acceptance Testing & Defect Logging
│   └── 1.5.4 Phase Gate 3 Review
├── 1.6 Configuration Management & QA (Week 6)
│   ├── 1.6.1 Git Branching Strategy & CI Pipeline Setup
│   └── 1.6.2 Static Analysis (Clang-Tidy/Cppcheck) & Code Metrics
├── 1.7 Deployment (Week 6)
│   └── 1.7.1 Deployment Diagram, Install Guide & User Manuals
└── 1.8 Maintenance & Completion (Week 7)
    ├── 1.8.1 Change Request Analysis (CR1 Implementation & Regression)
    ├── 1.8.2 Ethics, Legal & Professional Analysis
    ├── 1.8.3 Final Report Compilation & Traceability Matrix
    └── 1.8.4 Project Viva

---

## 2. Schedule, Dependencies & Critical Path

| Task ID | Task Description | Duration | Predecessors | Milestone / Gate |
| :--- | :--- | :--- | :--- | :--- |
| **T1.1** | Feasibility Study | 2 days | None | |
| **T1.2** | WBS & Schedule Definition | 2 days | T1.1 | |
| **T1.3** | Risk Management Plan | 1 day | T1.2 | **M1: Management Plan Signed Off** |
| **T2.1** | Stakeholder Conflict Resolution | 2 days | T1.3 | |
| **T2.2** | Write SRS Document | 3 days | T2.1 | |
| **T2.3** | Use Case Modeling & Specs | 3 days | T2.2 | **Gate 1: Requirements Review** |
| **T3.1** | System Architecture & Design Rationale | 2 days | T3.1 | |
| **T3.2** | Class Diagram & Pattern Selection | 3 days | T3.1 | |
| **T3.3** | Behavioural Modeling | 2 days | T3.2 | |
| **T3.4** | Database ERD & SQL Schema Design | 2 days | T3.2 | **Gate 2: Design Review** |
| **T4.1** | Core SQLite Data Layer & Security Setup | 3 days | T3.4 | |
| **T4.2** | User & Role Management Logic | 3 days | T4.1 | |
| **T4.3** | Assignment & Submission Life Cycle | 4 days | T4.2 | |
| **T4.4** | Moderation Engine & Audit Logging | 3 days | T4.3 | **M2: Code Freeze** |
| **T5.1** | Test Strategy Definition | 2 days | T3.4 | |
| **T5.2** | Unit & Integration Test Suite | 4 days | T4.4, T5.1 | |
| **T5.3** | System Acceptance & Defect Resolution | 3 days | T5.2 | **Gate 3: Testing Review** |
| **T6.1** | Static Analysis & CI/CD Pipeline Setup | 2 days | T5.2 | |
| **T7.1** | Deployment Packaging & User Documentation | 2 days | T5.3 | **M3: Release v1.0** |
| **T8.1** | Maintenance CR1 Impact Analysis & Code Update | 3 days | M3 | **M4: Release v1.1** |
| **T8.2** | Ethics, Final Report & Traceability Matrix | 3 days | T8.1 | |
| **T8.3** | Viva Preparation & Presentation | 1 day | T8.2 | **M5: Project Completion** |

### Critical Path Analysis
**Critical Path:** `T1.1` → `T1.2` → `T1.3` → `T2.1` → `T2.2` → `T2.3 (Gate 1)` → `T3.1` → `T3.2` → `T3.4 (Gate 2)` → `T4.1` → `T4.2` → `T4.3` → `T4.4` → `T5.2` → `T5.3 (Gate 3)` → `T7.1` → `T8.1` → `T8.2` → `T8.3`  
*Total Critical Path Duration: 49 Days (7 Weeks)*

---

## 3. Gantt Chart Representation (ASCII)

```
W1  : [T1.1][T1.2][T1.3--M1][T2.1  ]
W2  : [T2.2   ][T2.3---GATE 1][T3.1  ]
W3  : [T3.2   ][T3.3][T3.4---GATE 2]
W4  : [T4.1   ][T4.2   ][T4.3        ]
W5  : [T4.3][T4.4---M2][T5.1][T5.2   ]
W6  : [T5.2][T5.3--GATE 3][T6.1][T7.1--M3]
W7  : [T8.1---M4][T8.2      ][T8.3--M5]
```
