#include "DatabaseManager.hpp"
#include <stdexcept>
#include <iostream>

DatabaseManager::DatabaseManager(const std::string& dbPath) : db(nullptr) {
    if (sqlite3_open(dbPath.c_str(), &db) != SQLITE_OK) {
        throw std::runtime_error("Failed to open SQLite database");
    }
    sqlite3_exec(db, "PRAGMA journal_mode=WAL;", nullptr, nullptr, nullptr);
    sqlite3_exec(db, "PRAGMA foreign_keys = ON;", nullptr, nullptr, nullptr);
}

DatabaseManager::~DatabaseManager() {
    if (db) sqlite3_close(db);
}

DatabaseManager& DatabaseManager::getInstance(const std::string& dbPath) {
    static DatabaseManager instance(dbPath);
    return instance;
}

sqlite3* DatabaseManager::getConnection() { return db; }

void DatabaseManager::initializeSchema() {
    const char* schema = R"(
        CREATE TABLE IF NOT EXISTS Departments (
            department_id INTEGER PRIMARY KEY AUTOINCREMENT,
            department_name TEXT NOT NULL UNIQUE
        );
        CREATE TABLE IF NOT EXISTS Users (
            user_id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('Admin', 'Lecturer', 'HoD', 'Student')),
            department_id INTEGER
        );
        CREATE TABLE IF NOT EXISTS Courses (
            course_id INTEGER PRIMARY KEY AUTOINCREMENT,
            course_code TEXT NOT NULL UNIQUE,
            department_id INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS Assignments (
            assignment_id INTEGER PRIMARY KEY AUTOINCREMENT,
            course_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            due_date TEXT NOT NULL,
            max_mark REAL NOT NULL CHECK(max_mark > 0)
        );
        CREATE TABLE IF NOT EXISTS Submissions (
            submission_id INTEGER PRIMARY KEY AUTOINCREMENT,
            assignment_id INTEGER NOT NULL,
            student_id INTEGER NOT NULL,
            submitted_at TEXT NOT NULL,
            raw_mark REAL DEFAULT 0.0,
            final_mark REAL DEFAULT 0.0,
            feedback TEXT,
            status TEXT NOT NULL DEFAULT 'Submitted' CHECK(status IN ('Submitted', 'Late', 'Marked', 'Moderated', 'Released'))
        );
        CREATE TABLE IF NOT EXISTS AuditLogs (
            log_id INTEGER PRIMARY KEY AUTOINCREMENT,
            submission_id INTEGER NOT NULL,
            changed_by_user_id INTEGER NOT NULL,
            timestamp TEXT NOT NULL,
            old_mark REAL,
            new_mark REAL,
            reason TEXT NOT NULL
        );
    )";
    char* err = nullptr;
    sqlite3_exec(db, schema, nullptr, nullptr, &err);
}
