#include "UserRepository.hpp"
#include "DatabaseManager.hpp"
#include "UserFactory.hpp"
#include <iostream>

std::unique_ptr<User> UserRepository::authenticateUser(const std::string& username, const std::string& plainPassword) {
    sqlite3* db = DatabaseManager::getInstance().getConnection();
    const char* sql = "SELECT user_id, username, password_hash, role, department_id FROM Users WHERE username = ?;";
    sqlite3_stmt* stmt;
    
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) != SQLITE_OK) return nullptr;
    sqlite3_bind_text(stmt, 1, username.c_str(), -1, SQLITE_STATIC);
    
    std::unique_ptr<User> user = nullptr;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        int id = sqlite3_column_int(stmt, 0);
        std::string uname = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        std::string hash = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
        std::string role = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
        int deptId = sqlite3_column_int(stmt, 4);
        
        std::string inputHash = User::hashPassword(plainPassword);
        if (inputHash == hash) {
            user = UserFactory::createUser(id, uname, hash, role, deptId);
        }
    }
    sqlite3_finalize(stmt);
    return user;
}

bool UserRepository::registerUser(const std::string& username, const std::string& plainPassword, const std::string& role, int deptId) {
    sqlite3* db = DatabaseManager::getInstance().getConnection();
    const char* sql = "INSERT INTO Users (username, password_hash, role, department_id) VALUES (?, ?, ?, ?);";
    sqlite3_stmt* stmt;
    
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) != SQLITE_OK) return false;
    std::string hash = User::hashPassword(plainPassword);
    
    sqlite3_bind_text(stmt, 1, username.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, hash.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 3, role.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_int(stmt, 4, deptId);
    
    bool result = (sqlite3_step(stmt) == SQLITE_DONE);
    sqlite3_finalize(stmt);
    return result;
}
