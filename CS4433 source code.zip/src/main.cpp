#include <iostream>
#include "DatabaseManager.hpp"
#include "UserRepository.hpp"
#include "StandardLatePenalty.hpp"

int main() {
    std::cout << "=================================================\n";
    std::cout << "  Moderated Learning Management System (MLMS) v1.0 \n";
    std::cout << "  National University of Lesotho - CS4433         \n";
    std::cout << "=================================================\n\n";

    try {
        DatabaseManager::getInstance().initializeSchema();
        std::cout << "[SUCCESS] Local SQLite Database Initialized Successfully.\n";

        // Seed initial admin account
        UserRepository::registerUser("admin", "admin123", "Admin");
        UserRepository::registerUser("lecturer1", "pass123", "Lecturer", 1);
        UserRepository::registerUser("hod1", "pass123", "HoD", 1);
        UserRepository::registerUser("student1", "pass123", "Student", 1);

        std::cout << "[SUCCESS] Sample User Accounts Initialized.\n\n";

        std::string username, password;
        std::cout << "--- System Authentication ---\n";
        std::cout << "Username: ";
        std::cin >> username;
        std::cout << "Password: ";
        std::cin >> password;

        auto user = UserRepository::authenticateUser(username, password);
        if (user) {
            std::cout << "\n[AUTH SUCCESS] Welcome, " << user->getUsername() << "! Logged in as Role ID: " << static_cast<int>(user->getRole()) << "\n";
            
            StandardLatePenalty penaltyCalc;
            std::cout << "\n--- Penalty Strategy Test ---\n";
            std::cout << "Penalty for 1 Day Late (Max Mark 100): -" << penaltyCalc.calculateDeduction(1, 100) << " marks\n";
            std::cout << "Penalty for 4 Days Late (Max Mark 100): -" << penaltyCalc.calculateDeduction(4, 100) << " marks\n";
        } else {
            std::cout << "\n[AUTH ERROR] Invalid Credentials.\n";
        }

    } catch (const std::exception& e) {
        std::cerr << "[SYSTEM ERROR] " << e.what() << "\n";
        return 1;
    }

    return 0;
}
