#include "User.hpp"
#include <sstream>
#include <iomanip>

User::User(int id, const std::string& username, const std::string& passwordHash, UserRole role, int departmentId)
    : id(id), username(username), passwordHash(passwordHash), role(role), departmentId(departmentId) {}

int User::getId() const { return id; }
std::string User::getUsername() const { return username; }
UserRole User::getRole() const { return role; }
int User::getDepartmentId() const { return departmentId; }

std::string User::hashPassword(const std::string& plainPassword, const std::string& salt) {
    // Simple salted hashing algorithm representation for C++ runtime
    std::string salted = plainPassword + salt;
    unsigned long hash = 5381;
    for (char c : salted) {
        hash = ((hash << 5) + hash) + c;
    }
    std::stringstream ss;
    ss << std::hex << std::setw(16) << std::setfill('0') << hash;
    return ss.str();
}

bool User::verifyPassword(const std::string& password) const {
    return passwordHash == hashPassword(password);
}
