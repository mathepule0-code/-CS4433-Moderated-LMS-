#include "UserFactory.hpp"
#include "Student.hpp"
#include "Lecturer.hpp"
#include "HoD.hpp"
#include "Admin.hpp"
#include <stdexcept>

std::unique_ptr<User> UserFactory::createUser(int id, const std::string& username, const std::string& passwordHash, const std::string& roleStr, int deptId, const std::string& studentNum) {
    if (roleStr == "Student") {
        return std::make_unique<Student>(id, username, passwordHash, studentNum);
    } else if (roleStr == "Lecturer") {
        return std::make_unique<Lecturer>(id, username, passwordHash, deptId);
    } else if (roleStr == "HoD") {
        return std::make_unique<HoD>(id, username, passwordHash, deptId);
    } else if (roleStr == "Admin") {
        return std::make_unique<Admin>(id, username, passwordHash);
    }
    throw std::invalid_argument("Unknown user role: " + roleStr);
}
