# Moderated Learning Management System (MLMS)

## CS4433 Software Engineering Individual Project

### How to Build
```bash
mkdir build && cd build
cmake ..
make
./mlms
```
