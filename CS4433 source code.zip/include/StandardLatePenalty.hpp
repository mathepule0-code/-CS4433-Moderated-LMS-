#ifndef STANDARD_LATE_PENALTY_HPP
#define STANDARD_LATE_PENALTY_HPP

#include "IPenaltyStrategy.hpp"

class StandardLatePenalty : public IPenaltyStrategy {
public:
    double calculateDeduction(int daysLate, double maxMark) override {
        if (daysLate <= 0) return 0.0;
        if (daysLate > 3) return maxMark; // 100% loss after 3 days
        return maxMark * 0.10 * daysLate; // 10% deduction per day late
    }
};

#endif // STANDARD_LATE_PENALTY_HPP
