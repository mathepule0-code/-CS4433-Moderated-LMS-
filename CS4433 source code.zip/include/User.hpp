#ifndef USER_HPP
#ifndef USER_HPP
#define USER_HPP

#include <string>

enum class UserRole { Admin, Lecturer, HoD, Student };

class User {
protected:
    int id;
    std::string username;
    std::string passwordHash;
    UserRole role;
    int departmentId;

public:
    User(int id, const std::string& username, const std::string& passwordHash, UserRole role, int departmentId = 0);
    virtual ~User() = default;

    int getId() const;
    std::string getUsername() const;
    UserRole getRole() const;
    int getDepartmentId() const;
    bool verifyPassword(const std::string& password) const;
    
    static std::string hashPassword(const std::string& plainPassword, const std::string& salt = "CS4433_SALT_2026");
};

#endif // USER_HPP
