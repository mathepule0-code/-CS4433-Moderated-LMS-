#ifndef STUDENT_HPP
#define STUDENT_HPP

#include "User.hpp"

class Student : public User {
private:
    std::string studentNumber;
public:
    Student(int id, const std::string& username, const std::string& passwordHash, const std::string& studentNum)
        : User(id, username, passwordHash, UserRole::Student), studentNumber(studentNum) {}
    
    std::string getStudentNumber() const { return studentNumber; }
};

#endif // STUDENT_HPP
