#ifndef LECTURER_HPP
#define LECTURER_HPP

#include "User.hpp"

class Lecturer : public User {
public:
    Lecturer(int id, const std::string& username, const std::string& passwordHash, int deptId)
        : User(id, username, passwordHash, UserRole::Lecturer, deptId) {}
};

#endif // LECTURER_HPP
