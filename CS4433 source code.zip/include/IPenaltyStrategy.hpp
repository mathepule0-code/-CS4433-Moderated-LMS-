#ifndef IPENALTY_STRATEGY_HPP
#define IPENALTY_STRATEGY_HPP

class IPenaltyStrategy {
public:
    virtual ~IPenaltyStrategy() = default;
    virtual double calculateDeduction(int daysLate, double maxMark) = 0;
};

#endif // IPENALTY_STRATEGY_HPP
