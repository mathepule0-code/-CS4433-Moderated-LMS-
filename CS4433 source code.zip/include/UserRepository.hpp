#ifndef USER_REPOSITORY_HPP
#define USER_REPOSITORY_HPP

#include "User.hpp"
#include <memory>

class UserRepository {
public:
    static std::unique_ptr<User> authenticateUser(const std::string& username, const std::string& plainPassword);
    static bool registerUser(const std::string& username, const std::string& plainPassword, const std::string& role, int deptId = 0);
};

#endif // USER_REPOSITORY_HPP
