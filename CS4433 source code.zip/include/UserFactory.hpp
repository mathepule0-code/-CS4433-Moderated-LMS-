#ifndef USER_FACTORY_HPP
#define USER_FACTORY_HPP

#include "User.hpp"
#include <memory>

class UserFactory {
public:
    static std::unique_ptr<User> createUser(int id, const std::string& username, const std::string& passwordHash, const std::string& roleStr, int deptId = 0, const std::string& studentNum = "");
};

#endif // USER_FACTORY_HPP
