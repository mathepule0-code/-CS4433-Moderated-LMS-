#ifndef ADMIN_HPP
#define ADMIN_HPP

#include "User.hpp"

class Admin : public User {
public:
    Admin(int id, const std::string& username, const std::string& passwordHash)
        : User(id, username, passwordHash, UserRole::Admin) {}
};

#endif // ADMIN_HPP
