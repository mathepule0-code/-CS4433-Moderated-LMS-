#ifndef DATABASE_MANAGER_HPP
#define DATABASE_MANAGER_HPP

#include <sqlite3.h>
#include <string>

class DatabaseManager {
private:
    sqlite3* db;
    DatabaseManager(const std::string& dbPath);
public:
    ~DatabaseManager();
    static DatabaseManager& getInstance(const std::string& dbPath = "mlms.db");
    sqlite3* getConnection();
    void initializeSchema();

    DatabaseManager(const DatabaseManager&) = delete;
    DatabaseManager& operator=(const DatabaseManager&) = delete;
};

#endif // DATABASE_MANAGER_HPP
