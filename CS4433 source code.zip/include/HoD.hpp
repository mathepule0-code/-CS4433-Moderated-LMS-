#ifndef HOD_HPP
#define HOD_HPP

#include "User.hpp"

class HoD : public User {
public:
    HoD(int id, const std::string& username, const std::string& passwordHash, int deptId)
        : User(id, username, passwordHash, UserRole::HoD, deptId) {}
};

#endif // HOD_HPP
