# Phase 2 Deliverable: Software Requirements Specification (SRS)
**Standard:** Based on ISO/IEC/IEEE 29148  
**Project:** Moderated Learning Management System (MLMS)  

---

## 1. Functional Requirements (MoSCoW Prioritized)

| Req ID | Priority | Description | Verifiable Criterion |
| :--- | :--- | :--- | :--- |
| **FR-01** | **MUST** | The system shall authenticate users with role-based access control for Administrator, Lecturer, HoD, and Student [cite: 1]. | Login screen rejects invalid credentials and restricts menu options strictly to the authenticated user's role profile within 1 second. |
| **FR-02** | **MUST** | The Administrator shall be able to manage user accounts, departments, and courses [cite: 1]. | Admin can create/edit user records, assign department groupings, and set up courses in the SQLite database. |
| **FR-03** | **MUST** | The Administrator shall enrol students into courses and assign lecturers to specific courses [cite: 1]. | Enrolment records link valid student IDs to active course modules without orphan records. |
| **FR-04** | **MUST** | Lecturers shall create assignments specifying deadlines, maximum marks, and descriptions [cite: 1]. | Assignment records persist correctly with timestamp validation ensuring deadlines are set in the future. |
| **FR-05** | **MUST** | Students shall view enrolled courses/assignments and submit assignment files before deadlines [cite: 1, 2]. | Submission action creates an immutable record tied to the student ID with a precise system timestamp. |
| **FR-06** | **MUST** | Students may resubmit work prior to the assignment deadline, overwriting previous active drafts [cite: 1, 2]. | Resubmission updates the active submission file while preserving version history before the deadline cutoff. |
| **FR-07** | **SHOULD** | Lecturers shall grant individual deadline extensions to specific students when justified [cite: 1, 2]. | Extended deadlines correctly override standard course deadlines for the targeted student profile during grading. |
| **FR-08** | **MUST** | Lecturers shall grade submissions and record structured written feedback [cite: 1, 2]. | Numeric mark (bounded by max mark) and text feedback strings successfully save to the database entry. |
| **FR-09** | **MUST** | The system shall automatically calculate late penalties (10% deduction per day late up to 3 days; 0 after 3 days) [cite: 2]. | Submissions arriving 1 day past deadline automatically reflect a 10% score deduction in the grading interface. |
| **FR-10** | **MUST** | Heads of Department (HoD) shall review and moderate all departmental course marks [cite: 1, 2]. | HoD dashboard lists all marked submissions grouped by course/department for review and approval actions. |
| **FR-11** | **MUST** | The system shall restrict student mark visibility until the HoD explicitly releases approved marks [cite: 1, 2]. | Student portal displays "Pending Moderation" status until HoD status flag transitions to "Released". |
| **FR-12** | **MUST** | The system shall record an immutable audit log for every mark modification (who, when, old value, new value, reason) [cite: 1, 3]. | Any grade edit triggers an audit table insertion capturing administrator/lecturer ID, timestamp, delta, and justification note. |
| **FR-13** | **SHOULD** | The system shall track submission state transitions through a strict life cycle (Submitted, Late, Marked, Moderated, Released) [cite: 1]. | State machine rejects invalid transitions (e.g., direct jump from Submitted to Released without Marking/Moderation). |

---

## 2. Non-Functional Requirements (Measurable)

| Req ID | Category | Requirement Description | Measurable Verification Criteria |
| :--- | :--- | :--- | :--- |
| **NFR-01** | **Performance** | The system shall respond to user inputs and login requests within 2 seconds when loaded with 800 student records [cite: 2, 3]. | Benchmark testing with 800 mock student records completes authentication and dashboard rendering in $\le$ 2.0 seconds. |
| **NFR-02** | **Security** | Passwords shall never be stored in plaintext; they must be hashed using a recognized secure library with unique salts [cite: 3]. | Database inspection confirms password column contains secure hash strings (e.g., Argon2/bcrypt), matching zero plaintext entries. |
| **NFR-03** | **Reliability** | The system shall operate 100% offline on local hardware without requiring internet connectivity [cite: 2]. | Executing all core workflows (login, submission, grading, moderation) with network adapters disabled succeeds without errors. |
| **NFR-04** | **Usability** | The user interface shall be simple and intuitive to accommodate teachers with limited IT experience [cite: 2]. | Non-IT expert user testing yields task completion rates $\ge$ 90% without requiring technical documentation assistance. |
| **NFR-05** | **Maintainability** | The codebase shall be written in standard C++17, structured modularly, and achieve $\ge$ 70% unit test coverage [cite: 1, 4]. | CMake build succeeds without compiler warnings; GoogleTest coverage report confirms $\ge$ 70% line coverage of business logic. |
| **NFR-06** | **Data Integrity** | The database shall withstand sudden application termination or power loss without corruption [cite: 2]. | SQLite Write-Ahead Logging (WAL) and atomic transactions prevent table corruption during simulated sudden process kills. |
