# Phase 2 Deliverable: Stakeholder Analysis and Conflict Resolution
**Project:** Moderated Learning Management System (MLMS)  
**Course:** CS4433 Software Engineering  

---

## 1. Stakeholder Identification and Interests

| Stakeholder Role | Key Interests & Objectives |
| :--- | :--- |
| **Principal** | Administrative oversight, system simplicity for non-IT expert teachers [cite: 2], strict adherence to institutional grade governance (no unmoderated marks visible to students) [cite: 2]. |
| **Lecturer** | Efficient assignment creation, flexible extension management for valid student circumstances, immediate grading workflow, and prompt feedback delivery [cite: 1, 2]. |
| **Head of Department (HoD)** | Department-wide grade moderation and review control, enforcement of consistent academic policies (late penalties), and final authorization before student mark release [cite: 1, 2]. |
| **Student** | Clear viewing of enrolled courses and assignments, ability to resubmit work prior deadlines, receiving detailed written feedback rather than bare scores, and transparent grading [cite: 1, 2]. |
| **IT Officer** | Localized offline execution due to unreliable internet and aging hardware [cite: 2], secure credential management, fast performance under load (800 students), and low maintenance overhead [cite: 2, 3]. |

---

## 2. Identified Conflicts and Ambiguities

### Conflict 1: Mark Release Timing (Lecturer vs. Principal / HoD)
* **Description:** The Lecturer wants students to receive their marks as soon as grading is completed [cite: 2]. Conversely, the Principal and HoD mandate that students must not see any mark until it has been thoroughly reviewed, moderated, and approved by the HoD [cite: 2].
* **Resolution Strategy:** Implement a multi-stage submission lifecycle (`Submitted` $ightarrow$ `Marked` $ightarrow$ `Moderated` $ightarrow$ `Released`) [cite: 1]. Lecturers can view and enter grades immediately upon completion (satisfying lecturer workflow), but automated access control prevents student viewing until the HoD executes a formal "Release" action [cite: 1, 2].

### Conflict 2: Late Work Handling (HoD Policy vs. Student Representative)
* **Description:** The HoD specified that late work loses 10% of the available mark per day for up to three days, after which it receives zero [cite: 2]. The Student representative argued that late work should not simply be rejected and requested opportunities to fix mistakes and resubmit [cite: 2].
* **Resolution Strategy:** Adopt the HoD's quantitative penalty rule (10% deduction per day late, capping at 3 days resulting in a zero) while accommodating the student desire for acceptance by processing all late submissions rather than rejecting them outright [cite: 2]. Resubmissions are fully permitted *prior* to the official deadline (or approved extension date), after which the late penalty schedule governs late arrivals [cite: 1, 2].

---

## 3. Ambiguity Clarifications
* **System Environment:** Clarified with the IT officer that the application will run locally on school infrastructure using SQLite, completely bypassing internet dependency while supporting concurrent local access for 800 users [cite: 1, 2, 3].
* **Extension Scope:** Clarified that lecturers can grant individual deadline extensions for valid reasons, and post-release maintenance change requests (CR1) later expand this to class-wide extensions [cite: 1, 4].
