# Phase 2 Deliverable: Use Case Model and Specifications
**Project:** Moderated Learning Management System (MLMS)  

---

## 1. Use Case Diagram Overview
* **Actors:** `Administrator`, `Lecturer`, `Head of Department (HoD)`, `Student` [cite: 1].
* **System Boundary:** Moderated Learning Management System (MLMS Console/Desktop Application).
* **Relationships:**
  - All use cases include `Authenticate User` via `<<include>>`.
  - `Submit Assignment` may extend `Request Extension` via `<<extend>>`.
  - `User` is generalised into `Administrator`, `Lecturer`, `HoD`, and `Student`.

---

## 2. Fully Dressed Use Case Specifications

### UC-01: Submit Assignment (Mandatory)
* **Scope:** Moderated Learning Management System
* **Level:** User Goal
* **Primary Actor:** Student [cite: 1]
* **Preconditions:** 
  1. Student is authenticated and logged into the system [cite: 1, 2].
  2. The target assignment has been created by a lecturer and is currently active [cite: 1, 2].
* **Main Success Flow:**
  1. Student navigates to the "Enrolled Assignments" view [cite: 1, 2].
  2. Student selects an active assignment and chooses "Submit Work" [cite: 1, 2].
  3. Student enters submission content / file path [cite: 1, 2].
  4. System validates that the current system time is prior to the assignment deadline (or approved extension) [cite: 1, 2].
  5. System records the submission, timestamps it, sets status to `Submitted`, and saves it persistently to SQLite [cite: 1, 3].
  6. System displays a success confirmation message with submission reference details [cite: 1].
* **Alternative / Extension Flows:**
  * *4a. Submission is after the deadline:*
    1. System detects current time exceeds the deadline.
    2. System calculates late duration and applies standard late penalty rules (10% per day, up to 3 days) [cite: 2].
    3. System sets status to `Late` and logs the applied penalty percentage before saving [cite: 1, 2].
  * *4b. Deadline exceeded by more than 3 days:*
    1. System assigns a grade of zero due to excessive delay in accordance with policy [cite: 2].
  * *Resubmission Flow:* If prior submission exists and deadline has not passed, system overwrites active submission while archiving version history [cite: 1, 2].
* **Postconditions:** Submission is securely stored in SQLite with appropriate status (`Submitted` or `Late`) awaiting lecturer grading [cite: 1, 3].
* **Business Rules:** BR-SUB-01: Students may resubmit multiple times before the deadline [cite: 1, 2]. BR-SUB-02: Late submissions incur a 10% daily deduction up to 3 days [cite: 2].

---

### UC-02: Moderate and Release Marks
* **Scope:** Moderated Learning Management System
* **Level:** User Goal
* **Primary Actor:** Head of Department (HoD) [cite: 1]
* **Preconditions:**
  1. HoD is authenticated and logged into the system [cite: 1, 2].
  2. Submissions have been graded by lecturers (`Marked` state) within the HoD's department [cite: 1, 2].
* **Main Success Flow:**
  1. HoD selects "Department Grade Review" from the dashboard [cite: 1, 2].
  2. System displays all graded submissions awaiting moderation for departmental courses [cite: 1, 2].
  3. HoD reviews student marks, feedback, and audit logs [cite: 1, 3].
  4. HoD approves / moderates the grades and selects "Release Marks to Students" [cite: 1, 2].
  5. System updates submission status from `Marked` to `Moderated` and subsequently to `Released` [cite: 1].
  6. System logs the moderation approval action in the audit trail [cite: 1, 3].
  7. System makes released marks visible on student portals [cite: 1, 2].
* **Alternative / Exception Flows:**
  * *3a. HoD rejects/disputes a grade:*
    1. HoD flags the submission with revision comments and returns it to the lecturer with status `Needs Revision`.
    2. Lecturer adjusts grade and resubmits for HoD review.
* **Postconditions:** Approved marks are marked `Released` and become viewable by students [cite: 1, 2].
* **Business Rules:** BR-MOD-01: No student may view any mark until the HoD has explicitly released it [cite: 2]. BR-MOD-02: All mark adjustments are permanently recorded in the audit log [cite: 1, 3].

---

### UC-03: Create Assignment
* **Scope:** Moderated Learning Management System
* **Level:** User Goal
* **Primary Actor:** Lecturer [cite: 1]
* **Preconditions:**
  1. Lecturer is authenticated and assigned to the target course [cite: 1].
* **Main Success Flow:**
  1. Lecturer navigates to "My Courses" and selects a course module [cite: 1, 2].
  2. Lecturer selects "Create New Assignment" [cite: 1, 2].
  3. Lecturer inputs assignment title, description, maximum possible marks, and due date/time [cite: 1, 2].
  4. System validates that the due date is in the future and maximum mark is a positive integer [cite: 1, 2].
  5. System saves the new assignment record to the SQLite database [cite: 1, 3].
  6. System confirms successful creation and displays the assignment in the course schedule [cite: 1, 2].
* **Alternative / Exception Flows:**
  * *4a. Invalid date or missing fields:*
    1. System flags validation errors (e.g., past due date).
    2. Lecturer corrects input fields and re-submits.
* **Postconditions:** Assignment is created and active for enrolled students to view and submit against [cite: 1, 2].
* **Business Rules:** BR-AST-01: Assignments must have a future deadline and positive maximum mark [cite: 1, 2].
