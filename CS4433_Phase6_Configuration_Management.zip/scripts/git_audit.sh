#!/bin/bash
# Git Audit & Release Verification Script for MLMS (Phase 6)

echo "======================================================"
echo "  CS4433 MLMS - Git Repository Integrity Audit"
echo "======================================================"

echo ""
echo "[1] Checking Current Branch and Status..."
git status

echo ""
echo "[2] Listing All Release Tags..."
git tag -l -n1

echo ""
echo "[3] Verifying Commit History (Last 5 commits)..."
git log -n 5 --oneline --graph --decorate

echo ""
echo "[4] Verifying Tracked vs Untracked Files..."
git status --short

echo ""
echo "======================================================"
echo "  Audit Complete."
echo "======================================================"
