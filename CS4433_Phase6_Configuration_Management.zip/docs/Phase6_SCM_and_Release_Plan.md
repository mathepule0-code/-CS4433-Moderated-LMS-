# CS4433 - Phase 6: Software Configuration Management & Release Engineering Plan

## 1. Branching Strategy & Workflow Models
The Moderated Learning Management System (MLMS) project follows **GitFlow** and semantic versioning principles (`vMAJOR.MINOR.PATCH`).

### Branch Structure:
* `main` / `master`: Production-ready release code. Every commit is tagged with a release version (e.g., `v1.0`).
* `develop`: Integration branch for active feature completion.
* `feature/*`: Dedicated branches for individual functional modules (e.g., `feature/late-penalty-strategy`).
* `hotfix/*`: Emergency patches branched off `main` for critical production bug fixes.

---

## 2. Release Management & Semantic Versioning

| Tag / Release | Date | Commit Hash | Scope / Deliverables | Baseline Status |
|---|---|---|---|---|
| **v0.1-alpha** | Week 2 | `a1b2c3d` | Phase 1 & 2 Requirements, SRS & Architecture Diagrams | Approved Baseline |
| **v0.5-beta** | Week 4 | `e5f6g7h` | Phase 3 Structural Design, Class Schemas & 3NF ERD | Approved Baseline |
| **v1.0** | Week 6 | `j9k0l1m` | Phase 4 Full Implementation (C++17, SQLite, CLI Interface) | Approved Release |
| **v1.1** | Week 8 | `n2o3p4q` | Phase 5 GoogleTest Suite, QA Verification & Automation | Current Target |

---

## 3. Configuration Identification & Change Management

### Tracked Artifacts:
1. **Source Code**: `.hpp` and `.cpp` files under `/include` and `/src`.
2. **Build Configuration**: `CMakeLists.txt` build targets and dependencies.
3. **Database Schema**: Versioned SQLite DDL migration scripts.
4. **Documentation**: LaTeX/Markdown specs for SRS, SDD, and QA plans.

### Change Request (CR) Process:
1. **Initiation**: Submit a GitHub Issue detailing the change requirement.
2. **Evaluation**: Perform impact analysis on existing architectural components.
3. **Approval**: Approval required by Project Lead / System Architect.
4. **Merge**: Code review via Pull Request (PR) with mandatory passing unit tests.
