# CS4433 - Phase 5: Software Testing, Quality Assurance & Verification Plan

## 1. Quality Assurance Strategy & Test Scope
The Phase 5 Testing framework for the Moderated Learning Management System (MLMS) provides end-to-end verification across unit components, integration pipelines, security controls, and database operations.

### Key Quality Metrics:
* **Statement Coverage Target**: > 85% across model domain classes.
* **Functional Correctness**: 100% compliance with SRS business rules (Role-Based Access Control & Late Penalty Calculations).
* **Data Integrity**: Zero SQL Injection vulnerability via prepared statement verification.

---

## 2. Requirements Traceability Matrix (RTM)

| Test ID | Associated Requirement | Domain | Test Type | Test Description | Expected Result | Status |
|---|---|---|---|---|---|---|
| **TC-UNIT-01** | FR-PEN-01 (Late Penalty) | Strategy Pattern | Unit Test | Verify 0-day late submission incurs 0 deduction | 0.0 deduction | PASS |
| **TC-UNIT-02** | FR-PEN-02 (Late Penalty) | Strategy Pattern | Unit Test | Verify 1-day late submission deducts 10% | 10% max mark deduction | PASS |
| **TC-UNIT-03** | FR-PEN-03 (Late Penalty) | Strategy Pattern | Unit Test | Verify >3 days late submission results in 100% deduction | 100.0 deduction | PASS |
| **TC-UNIT-04** | NFR-SEC-01 (Authentication) | User/Security | Unit Test | Verify password hashing via `hashPassword` produces salted non-reversible hash | Valid Hash Generation | PASS |
| **TC-INT-01** | FR-AUTH-01 (RBAC) | User Repository | Integration | Register new student account and execute `authenticateUser` query | User object instantiated correctly | PASS |
| **TC-INT-02** | NFR-DB-01 (Persistence) | Database Manager | Integration | Initialize SQLite schema tables, indexes, and WAL journal mode | Tables created with FK constraints | PASS |

---

## 3. How to Build & Run Test Suite

```bash
mkdir build
cd build
cmake ..
make
ctest --output-on-failure
```
