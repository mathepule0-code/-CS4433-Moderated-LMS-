#include <gtest/gtest.h>
#include "UserFactory.hpp"
#include "Student.hpp"

TEST(UserTest, PasswordHashingAndVerification) {
    std::string pass = "secret123";
    std::string hash = User::hashPassword(pass);
    
    EXPECT_FALSE(hash.empty());
    EXPECT_NE(hash, pass);
    
    Student student(1, "student_test", hash, "600123");
    EXPECT_TRUE(student.verifyPassword(pass));
    EXPECT_FALSE(student.verifyPassword("wrongpass"));
}

TEST(UserFactoryTest, RoleInstantiations) {
    auto student = UserFactory::createUser(1, "s1", "hash", "Student", 0, "600100");
    EXPECT_EQ(student->getRole(), UserRole::Student);

    auto lecturer = UserFactory::createUser(2, "l1", "hash", "Lecturer", 10);
    EXPECT_EQ(lecturer->getRole(), UserRole::Lecturer);
    EXPECT_EQ(lecturer->getDepartmentId(), 10);
}
