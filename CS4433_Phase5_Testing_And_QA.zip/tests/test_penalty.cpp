#include <gtest/gtest.h>
#include "StandardLatePenalty.hpp"

TEST(PenaltyStrategyTest, OnTimeSubmission) {
    StandardLatePenalty penalty;
    EXPECT_DOUBLE_EQ(penalty.calculateDeduction(0, 100.0), 0.0);
}

TEST(PenaltyStrategyTest, OneDayLate) {
    StandardLatePenalty penalty;
    EXPECT_DOUBLE_EQ(penalty.calculateDeduction(1, 100.0), 10.0);
}

TEST(PenaltyStrategyTest, ThreeDaysLate) {
    StandardLatePenalty penalty;
    EXPECT_DOUBLE_EQ(penalty.calculateDeduction(3, 100.0), 30.0);
}

TEST(PenaltyStrategyTest, BeyondThreeDaysLate) {
    StandardLatePenalty penalty;
    // Beyond 3 days results in 100% loss of marks
    EXPECT_DOUBLE_EQ(penalty.calculateDeduction(4, 100.0), 100.0);
}
