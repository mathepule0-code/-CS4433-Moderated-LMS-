#include <gtest/gtest.h>
#include "DatabaseManager.hpp"
#include "UserRepository.hpp"

class DatabaseTest : public ::testing::Test {
protected:
    void SetUp() override {
        // Initialize SQLite in-memory/temp database schema
        DatabaseManager::getInstance("test_mlms.db").initializeSchema();
    }
};

TEST_F(DatabaseTest, RegisterAndAuthenticateUser) {
    bool regResult = UserRepository::registerUser("unit_test_user", "test_pass", "Student", 1);
    EXPECT_TRUE(regResult);

    auto user = UserRepository::authenticateUser("unit_test_user", "test_pass");
    ASSERT_NE(user, nullptr);
    EXPECT_EQ(user->getUsername(), "unit_test_user");
    EXPECT_EQ(user->getRole(), UserRole::Student);
}
